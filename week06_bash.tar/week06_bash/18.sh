#! /bin/bash

SHCNT=$(find . -name "*.sh" | wc -l)

echo $SHCNT